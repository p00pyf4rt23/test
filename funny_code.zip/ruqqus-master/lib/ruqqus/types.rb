
# Bootstrap script to load all concrete Ruqqus types

require_relative 'types/item_base'
require_relative 'types/submission'
require_relative 'types/comment'
require_relative 'types/guild'
require_relative 'types/post'
require_relative 'types/badge'
require_relative 'types/title'
require_relative 'types/user'
